﻿
namespace Labo1
{
    partial class Lab1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonUsager = new System.Windows.Forms.Button();
            this.buttonMDP = new System.Windows.Forms.Button();
            this.buttonValidationMDP = new System.Windows.Forms.Button();
            this.textBoxUsager = new System.Windows.Forms.TextBox();
            this.textBoxMDP = new System.Windows.Forms.TextBox();
            this.textBoxValidationMDP = new System.Windows.Forms.TextBox();
            this.buttonValider = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonUsager
            // 
            this.buttonUsager.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonUsager.Location = new System.Drawing.Point(12, 37);
            this.buttonUsager.Name = "buttonUsager";
            this.buttonUsager.Size = new System.Drawing.Size(168, 36);
            this.buttonUsager.TabIndex = 0;
            this.buttonUsager.Text = "Usager :";
            this.buttonUsager.UseVisualStyleBackColor = true;
            this.buttonUsager.Click += new System.EventHandler(this.buttonUsager_Click);
            // 
            // buttonMDP
            // 
            this.buttonMDP.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonMDP.Location = new System.Drawing.Point(12, 96);
            this.buttonMDP.Name = "buttonMDP";
            this.buttonMDP.Size = new System.Drawing.Size(168, 34);
            this.buttonMDP.TabIndex = 1;
            this.buttonMDP.Text = "Mot de passe : ";
            this.buttonMDP.UseVisualStyleBackColor = true;
            // 
            // buttonValidationMDP
            // 
            this.buttonValidationMDP.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonValidationMDP.Location = new System.Drawing.Point(12, 152);
            this.buttonValidationMDP.Name = "buttonValidationMDP";
            this.buttonValidationMDP.Size = new System.Drawing.Size(245, 30);
            this.buttonValidationMDP.TabIndex = 2;
            this.buttonValidationMDP.Text = "Validation mot de passe : ";
            this.buttonValidationMDP.UseVisualStyleBackColor = true;
            // 
            // textBoxUsager
            // 
            this.textBoxUsager.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxUsager.Location = new System.Drawing.Point(382, 43);
            this.textBoxUsager.Name = "textBoxUsager";
            this.textBoxUsager.Size = new System.Drawing.Size(314, 30);
            this.textBoxUsager.TabIndex = 3;
            this.textBoxUsager.TextChanged += new System.EventHandler(this.textBoxUsager_TextChanged);
            // 
            // textBoxMDP
            // 
            this.textBoxMDP.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxMDP.Location = new System.Drawing.Point(382, 96);
            this.textBoxMDP.Name = "textBoxMDP";
            this.textBoxMDP.Size = new System.Drawing.Size(314, 30);
            this.textBoxMDP.TabIndex = 4;
            this.textBoxMDP.TextChanged += new System.EventHandler(this.textBoxMDP_TextChanged);
            // 
            // textBoxValidationMDP
            // 
            this.textBoxValidationMDP.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxValidationMDP.Location = new System.Drawing.Point(382, 152);
            this.textBoxValidationMDP.Name = "textBoxValidationMDP";
            this.textBoxValidationMDP.Size = new System.Drawing.Size(314, 30);
            this.textBoxValidationMDP.TabIndex = 5;
            this.textBoxValidationMDP.TextChanged += new System.EventHandler(this.textBoxValidationMDP_TextChanged);
            // 
            // buttonValider
            // 
            this.buttonValider.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonValider.Location = new System.Drawing.Point(528, 214);
            this.buttonValider.Name = "buttonValider";
            this.buttonValider.Size = new System.Drawing.Size(168, 36);
            this.buttonValider.TabIndex = 6;
            this.buttonValider.Text = "Valider";
            this.buttonValider.UseVisualStyleBackColor = true;
            this.buttonValider.Click += new System.EventHandler(this.buttonValider_Click);
            // 
            // Lab1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(800, 275);
            this.Controls.Add(this.buttonValider);
            this.Controls.Add(this.textBoxValidationMDP);
            this.Controls.Add(this.textBoxMDP);
            this.Controls.Add(this.textBoxUsager);
            this.Controls.Add(this.buttonValidationMDP);
            this.Controls.Add(this.buttonMDP);
            this.Controls.Add(this.buttonUsager);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "Lab1";
            this.Text = "Sif Marchane - Validation d\'un mot de passe";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Lab1_FormClosing);
            this.Load += new System.EventHandler(this.Lab1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonUsager;
        private System.Windows.Forms.Button buttonMDP;
        private System.Windows.Forms.Button buttonValidationMDP;
        private System.Windows.Forms.TextBox textBoxUsager;
        private System.Windows.Forms.TextBox textBoxMDP;
        private System.Windows.Forms.TextBox textBoxValidationMDP;
        private System.Windows.Forms.Button buttonValider;
    }
}

