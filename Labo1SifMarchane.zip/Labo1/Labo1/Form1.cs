﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Labo1
{
    public partial class Lab1 : Form
    {
        public Lab1()
        {
            InitializeComponent();
        }

        private void Lab1_Load(object sender, EventArgs e)
        {
            buttonValider.Select();
            buttonValider.Enabled = false;
        }

        private void buttonUsager_Click(object sender, EventArgs e)
        {

        }

        private void textBoxUsager_TextChanged(object sender, EventArgs e)
        {
            textBoxUsager.Text = String.Concat(textBoxUsager.Text.Where(char.IsLetterOrDigit));
            
                buttonValider.Enabled = true;
            
        }

        private void buttonValider_Click(object sender, EventArgs e)
        {
            String MotDePasse = textBoxMDP.Text;
            if (MotDePasse.Length >= 10 && MotDePasse.Any(char.IsUpper) && MotDePasse.Any(char.IsLower)
                    && MotDePasse.Any(char.IsDigit))
            {
                buttonValider.Enabled = true;
            }
            String Valider = textBoxValidationMDP.Text;
            if(Valider.Length >= 10 && Valider.Any(char.IsUpper) && Valider.Any(char.IsLower)
                 && Valider.Any(char.IsDigit))
            {
                buttonValider.Enabled = true;
            }
            if (textBoxValidationMDP.Text == textBoxMDP.Text && MotDePasse.Length >= 10 && MotDePasse.Any(char.IsUpper)
                && MotDePasse.Any(char.IsLower) && MotDePasse.Any(char.IsDigit))
            {
                MessageBox.Show(textBoxUsager.Text + " votre mot de passe est valide.");
            }else
            {
                MessageBox.Show(textBoxUsager.Text + " votre mot de passe ou votre nom d'usager est invalide.");
            }
        }

        private void textBoxMDP_TextChanged(object sender, EventArgs e)
        {
            textBoxMDP.UseSystemPasswordChar = true;

            if (textBoxUsager.Text != "" && textBoxMDP.Text != "" && textBoxValidationMDP.Text != "")
            {
                buttonValider.Enabled = true;
            }
        }

        private void textBoxValidationMDP_TextChanged(object sender, EventArgs e)
        {
            textBoxValidationMDP.UseSystemPasswordChar = true;

            if(textBoxUsager.Text != "" && textBoxMDP.Text != "" && textBoxValidationMDP.Text != "")
            {
                buttonValider.Enabled = true;
            }
        }
        private void Lab1_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult resultat = MessageBox.Show(" Voulez-vous vraiment quitter ? ", "Fermeture de l'application",
            MessageBoxButtons.OKCancel);

            if (resultat == DialogResult.Cancel)
            {
                e.Cancel = true;
            }

        }
    }
}
